const timesTamp = +new Date();

console.log(timesTamp);
